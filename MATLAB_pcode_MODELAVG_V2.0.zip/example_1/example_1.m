% ----------------------------------------------------------------------------------------- %
%                                                                                           %
% MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LL            AAA      VV       VV  GGGGGGGG %
% MMM      MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LL           AA AA     VV       VV  GG    GG %
% MMMM   MMMM  OO     OO  DD     DD  EE        LL           AA AA      VV     VV   GG    GG %
% MM MM MM MM  OO     OO  DD     DD  EEEEE     LL          AA   AA     VV     VV   GGGGGGGG %
% MM  MMM  MM  OO     OO  DD     DD  EEEEE     LL         AAAAAAAAA     VV   VV    GGGGGGGG %
% MM       MM  OO     OO  DD     DD  EE        LL         AA     AA      VV VV           GG %
% MM       MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LLLLLLLL  AA       AA     VV VV      GGGGGGG %
% MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LLLLLLLL  AA       AA      VVV      GGGGGGGG %
%                                                                                           %
% ----------------------------------------------------------------------------------------- %

%% CASE STUDY I: RAINFALL-RUNOFF TRANSFORMION - ENSEMBLE OF CALIBRATED WATERSHED MODELS
%% CHECK: J.A. VRUGT AND B.A. ROBINSON, WRR, 43, W01411, doi:10.1029/2005WR004838, 2007

%% DEFINE MODEL AVERAGING METHOD
method = 'bma';             % 'ewa'/'bga'/'aica'/'bica'/'gra'/'bma'/'mma'/'mma-s'

%% BMA -> CONDITIONAL DISTRIBUTION NEEDS TO BE DEFINED
options.PDF = 'normal';    % weibull conditional pdf ('normal','lognormal','tnormal','gen_normal','weibull','gamma')
options.VAR = '2';          % individual constant ( = homoscedastic ) variance ('1' homos group, '2' homos sole, '3' heteros group, '4' heteros sole)
options.TAU = '2';          % only for generalized normal (gen_normal) - own tau for each member individually
options.alpha = [0.5 0.90 0.95]; % prediction intervals of BMA model (0.90/0.95/0.99)
options.print = 'yes';      % print output (figures, tables) to screen
options.CPU = 'yes';        % CPU efficient or not

%% NOW LOAD DATA
S = load('discharge.txt');  % daily discharge forecasts (mm/day) of models and verifying data 
idx_cal = 1:1:3000;         % start/end training period
idx_eval = 5001:7000;       % evaluation period

%% DEFINE ENSEMBLE AND VECTOR OF VERYFYING OBSERVATIONS
D = S(idx_cal,1:8); y = S(idx_cal,9);

%% APPLY LINEAR BIAS CORRECTION TO ENSEMBLE ( UP TO USER )
[ D , a , b ] = Bias_correction ( D , y );

%% NUMBER OF PARAMETERS OF EACH MODEL (ABC/GR4J/HYMOD/TOPMO/AWBM/NAM/HBV/SACSMA)
options.p = [ 3 4 5 8 8 9 9 13 ];   % ( only used for AICA, BICA, MMA, MMA-S)

%% Run MODELAVG toolbox with two outputs
[ phi , output ] = MODELAVG ( method , D , y , options );

%% NOW DEFINE EVALUATION DATA
D_eval = S(idx_eval,1:8); y_eval = S(idx_eval,9);

%% NOW CALCULATE STATISTICS FOR EVALUATION PERIOD
val = MODELAVG_eval ( method , D_eval , y_eval , options , a , b , output )
