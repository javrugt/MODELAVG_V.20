%% ------------------------------------------------------------------------------------------- %%
%%                                                                                             %%
%%  MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LL            AAA      VV       VV  GGGGGGGG  %%
%%  MMM      MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LL           AA AA     VV       VV  GG    GG  %%
%%  MMMM   MMMM  OO     OO  DD     DD  EE        LL           AA AA      VV     VV   GG    GG  %%
%%  MM MM MM MM  OO     OO  DD     DD  EEEEE     LL          AA   AA     VV     VV   GGGGGGGG  %%
%%  MM  MMM  MM  OO     OO  DD     DD  EEEEE     LL         AAAAAAAAA     VV   VV    GGGGGGGG  %%
%%  MM       MM  OO     OO  DD     DD  EE        LL         AA     AA      VV VV           GG  %%
%%  MM       MM  OOOOOOOOO  DDDDDDDDD  EEEEEEEE  LLLLLLLL  AA       AA     VV VV          GGG  %%
%%  MM       MM   OOOOOOO   DDDDDDDD   EEEEEEEE  LLLLLLLL  AA       AA      VVV      GGGGGGGG  %%
%%                                                                                             %%
%% ------------------------------------------------------------------------------------------- %%

%% CASE STUDY I: RAINFALL-RUNOFF TRANSFORMION - ENSEMBLE OF CALIBRATED WATERSHED MODELS
%% PLEASE CHECK: J.A. VRUGT AND B.A. ROBINSON, WRR, 43, W01411, doi:10.1029/2005WR004838, 2007

%% DEFINE MODEL AVERAGING METHOD
method = 'bma';             % 'ewa'/'bga'/'aica'/'bica'/'gra'/'bma'/'mma'/'mma-s'

%% BMA -> CONDITIONAL DISTRIBUTION NEEDS TO BE DEFINED
options.PDF = 'tnormal';    % Truncated normal conditional pdf
%options.TAU = '2';          % variable tau for all models - only for gen_normal PDF
options.VAR = '2';          % individual constant variance
options.alpha = [0.50 0.90 0.95 0.99];       % prediction intervals of BMA model (0.90/0.95/0.99)
options.print = 'yes';      % print output (figures, tables) to screen

%% NOW LOAD DATA
W = load('water_levels.txt');   % daily discharge forecasts (mm/day) of models and verifying data 
idx_cal = 1:18;                 % indices of training period
idx_eval = 19:size(W,1);        % indices of evaluation data period

%% DEFINE TRAINING ENSEMBLE AND VECTOR OF VERYFYING OBSERVATIONS
D_cal = W(idx_cal,1:3); y_cal = W(idx_cal,4); 

%% APPLY LINEAR BIAS CORRECTION TO ENSEMBLE ( UP TO USER )
[ D , a , b ] = Bias_correction ( D_cal , y_cal );

%% NUMBER OF PARAMETERS OF EACH MODEL (ABC/GR4J/HYMOD/TOPMO/AWBM/NAM/HBV/SACSMA)
options.p = [ 3 3 4 ];   % ( only used for AICA, BICA, MMA, MMA-S)

%% Run MODELAVG toolbox with two outputs
[ phi , output ] = MODELAVG ( method , D , y_cal , options );

%% DEFINE EVALUATION ENSEMBLE AND VECTOR OF VERYFYING OBSERVATIONS
D_eval = W(idx_eval,1:3); y_eval = W(idx_eval,4);

%% Now evaluate BMA model
% val = MODELAVG_eval ( method , D_eval , y_eval , options , a , b , output );