%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%
%%                                                                                    %%
%% MM       MM  OOOOOOO  DDDDDDDD  EEEEEEEE LL           AAA     VV       VV GGGGGGGG %%
%% MMM      MM OOOOOOOOO DDDDDDDDD EEEEEEEE LL          AA AA    VV       VV GG    GG %%
%% MMMM   MMMM OO     OO DD     DD EE       LL          AA AA     VV     VV  GG    GG %%
%% MM MM MM MM OO     OO DD     DD EEEEE    LL         AA   AA    VV     VV  GGGGGGGG %%
%% MM  MMM  MM OO     OO DD     DD EEEEE    LL        AAAAAAAAA    VV   VV   GGGGGGGG %%
%% MM       MM OO     OO DD     DD EE       LL        AA     AA     VV VV          GG %%
%% MM       MM OOOOOOOOO DDDDDDDDD EEEEEEEE LLLLLLLL AA       AA    VV VV         GGG %%
%% MM       MM  OOOOOOO  DDDDDDDD  EEEEEEEE LLLLLLLL AA       AA     VVV     GGGGGGGG %%
%%                                                                                    %%
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%

%% FOR BMA ENSEMBLE OF WATERSHED MODELS
%% J.A. VRUGT AND B.A. ROBINSON, WRR, 43, W01411, doi:10.1029/2005WR004838, 2007

%% FOR PERFORMANCE METRICS & SCORING RULES OF BMA MIXTURE DISTRIBUTION
%% https://www.authorea.com/users/597576/articles/632989-the-promise-of-diversity-distribution-based-hydrologic-model-evaluation-and-diagnostics
%% Revised manuscript: submitted to WRR 

%% DEFINE MODEL AVERAGING METHOD
method = 'bma';             % 'ewa'/'bga'/'aica'/'bica'/'gra'/'bma'/'mma'/'mma-s'

%% FIXED SETTINGS
options.alpha = [0.95 0.75 0.5];   % prediction intervals of BMA model
options.print = 'no';              % print output (figures, tables) to screen
options.CPU = 'yes';

%% NOW LOAD DATA
S = load('discharge.txt');  % daily discharge forecasts (mm/day) of models and verifying data
idx_cal = 1:1:3000;         % start/end training period
idx_eval = 5001:7000;       % evaluation period
%% DEFINE ENSEMBLE AND VECTOR OF VERYFYING OBSERVATIONS
D = S(idx_cal,1:8); y = S(idx_cal,9); D_eval = S(idx_eval,1:8); y_eval = S(idx_eval,9); 
%% APPLY LINEAR BIAS CORRECTION TO ENSEMBLE ( UP TO USER )
[ D , a_LB , b_LB ] = Bias_correction ( D , y );
%% NUMBER OF PARAMETERS OF EACH MODEL (ABC/GR4J/HYMOD/TOPMO/AWBM/NAM/HBV/SACSMA)
%% options.p = [ 3 4 5 8 8 9 9 13 ];   % ( only used for AICA, BICA, MMA, MMA-S)

%% BMA CONDITIONAL DISTRIBUTIONS TO BE USED
PDF = {'normal', ...        % Normal distribution
    'lognormal', ...        % Lognormal distribution
    'gen_normal', ...       % Generalized normal distribution
    'tnormal', ...          % Truncated normal distribution
    'gamma', ...            % Gamma distribution
    'gev', ...              % Generalized Pareto distribution
    'gpareto'};             % Generalized extreme value distribution
V = {'1','2','3','4'};      % homoscedastic variance; group: '1' ; single: '2'
                            % heteroscedastic variance; group: '3' ; single: '4'

%% BMA -> CONDITIONAL DISTRIBUTION NEEDS TO BE DEFINED
options.TAU = '2';  % Generalized normal: different tau for each ensemble member
                    % Generalized Pareto: different xi (shape) parameter for each ensemble member
                    % Generalized extreme value: different xi (shape) parameter for each ensemble member

which_period = 'calibration';

% Table formulation
% 'normal','lognormal','gen_normal','tnormal','gamma','gev','gpareto'
%    1          2           3           4        5      6      7     Var = '1'
%    8          9          10          11       12     13     14     Var = '2'
%   15         16          17          18       19     20     21     Var = '3'
%   22         23          24          25       26     27     28     Var = '4'
names_pdf = {'1: normal: const group',...
    '2: lnormal: const group', ...
    '3: gnormal: const group', ...
    '4: tnormal: const group', ...
    '5: gamma: const group', ...
    '6: gev: const group', ...
    '7: gp: const group', ...
    '8: normal: const ind',...
    '9: lnormal: const ind', ...
    '10: gnormal: const ind', ...
    '11: tnormal: const ind', ...
    '12: gamma: const ind', ...
    '13: gev: const ind', ...
    '14: gp: const ind', ...
    '15: normal: nonconst group',...
    '16: lnormal: nonconst group', ...
    '17: gnormal: nonconst group', ...
    '18: tnormal: nonconst group', ...
    '19: gamma: nonconst group', ...
    '20: gev: nonconst group', ...
    '21: gp: nonconst group', ...
    '22: normal: nonconst ind',...
    '23: lnormal: nonconst ind', ...
    '24: gnormal: nonconst ind', ...
    '25: tnormal: nonconst ind', ...
    '26: gamma: nonconst ind', ...
    '27: gev: nonconst ind', ...
    '28: gp: nonconst ind'};

%% INITIALIZE VARIABLES/OUTPUT ARRAYS
nV = numel(V); nPDF = numel(PDF);
switch which_period
    case 'calibration'
        nY = numel(y);
    case 'evaluation'
        nY = numel(y_eval);
end
output = cell(1,nV*nPDF);
% Prepare to run in parallel
ct = 1;
for i = 1:nV
    for j = 1:nPDF
        V_and_PDF(ct,1:2) = [V(i) , PDF(j)];
        ct = ct + 1;
    end
end

%% Now do BMA method for all combinations of variances/conditional PDFs
parfor i = 1:nV*nPDF
    i
    VPDF = V_and_PDF(i,1:2);
    % Call function below - parallel implementation
    [output{i},beta{i},AR{i},table_res(:,i)] = ...
        parallel_script(VPDF,method,D,y,options,which_period,a_LB,b_LB,D_eval,y_eval);
    % Results in table_res (8 processors)
end
evalstr = strcat('save results_',which_period); eval(char(evalstr));

%% print some tables
print_tables

%% print some figures
print_figures

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% SECONDARY FUNCTION
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [output,beta,AR,table_res] = ...
    parallel_script(VPDF,method,D,y,options,which_period,a_LB,b_LB,D_eval,y_eval)

%% Now do BMA method for all combinations of variances/conditional PDFs
options.VAR = char(VPDF(1));       % Group/sole variance
% Define conditional pdf
options.PDF = char(VPDF(2));
% Run MODELAVG toolbox with two outputs
[ beta , output ] = MODELAVG ( method , D , y , options ); AR = output.AR;

switch which_period
    case 'calibration'
        % Evaluate performance calibration period
        table_res = [ output.mQS output.mLS output.mSS output.mCRPS ...
            output.mRLBL_anal output.mCv_anal ...
            output.coverage(1)/100 output.spread(1) output.loglik ... 
            output.RMSE output.R2 output.KGE ]';
    case 'evaluation'
        % Evaluate maximum likelihood BMA forecast distribution for evaluation period
        [val,D_eval] = MODELAVG_eval ( method , D_eval , y_eval , options , a_LB , b_LB , output );
        % Return table with results
        table_res = [ val.mQS val.mLS val.mSS val.mCRPS ...
            val.mRLBL_anal val.mCv_anal ...
            val.coverage(1)/100 val.spread(1) val.loglik ... 
            val.RMSE val.R2 val.KGE ]';
end

end