%% Now print Table 9 using Latex language
type_table = 'heteros_only'; % 'homos_only' , 'heteros_only';
col1 = {'$\text{QS}$','$\text{LS}$','$\text{SS}$',...
    '$\text{CRPS}$','$R_\text{l}$','$C_\text{v}$','$C$',...
    '$W$','$\ell(\widehat{\bm{\Phi}}\vert \bm{\upomega})$','$\text{RMSE}$',...
    '$\text{NSE}$','\text{KGE}'};
switch type_table
    case 'homos_only'
        % order     normal  logn    gnorm   tnorm  gamma   GEV
        idx_col = [  1 8  , 2 9   , 3 10  , 4 11  , 5 12  , 6 13 ];
    case 'heteros_only'
        % order     normal  logn    gnorm   tnorm  gamma   GEV
        idx_col = [ 15 22 , 16 23 , 17 24 , 18 25 , 19 26 , 20 27 ];
    case 'homos_heteros' % without normal
        % order     normal  logn   gnorm    tnorm  gamma   GEV
        idx_col = [ 1 15 , 2  16 ,  3  17 , 4  18 , 5  19 , 6  20 ]; % single parameter
       % idx_col = [ 8 22 , 9  23 ,  10 24 , 11 25 , 12 26 , 13 27 ]; % multiple parameters

end
nd = numel(idx_col);
Table_9 = table_res(:,idx_col);
for i = 1:numel(col1)
    str = cell(1,nd);
    for z = 1:nd
        if Table_9(i,z) > 0
            str{z} = strcat('\multicolumn{1}{r}{$',num2str(Table_9(i,z),'%5.3f'),'$}');
        else
            str{z} = strcat('\multicolumn{1}{r}{-$',num2str(abs(Table_9(i,z)),'%5.3f'),'$}');
        end
    end
    switch type_table
        case {'homos_only','heteros_only'}
            % regular order: normal, lognormal, gen_normal, gamma, weibull
            fprintf('%s & %s & %s & %s & %s && %s & %s & %s & %s && %s & %s & %s & %s && %s & %s & %s & %s && %s & %s & %s & %s && %s & %s & %s & %s \\\\',...
                strcat(char(col1(i))),str{1:end});
        otherwise
            % new order: lognormal, weibull (homos) normal, gen_normal, gamma (heteros)
            str_tab = strcat('%s');
            for ii = 1:nd
                str_tab = strcat(str_tab,' & %s');
            end
            str_tab = strcat(str_tab,'\\\\');
            fprintf(str_tab,strcat(char(col1(i))),str{1:end});
    end
    fprintf('\n');
end

%% Rank the distributions for each storing rule
format long
Rk = cell(1,4); ncol = numel(idx_col);
Rk_num = nan(ncol,4);
ii_col = [1 1 , 2 2 , 3 3 , 4 4 , 5 5 , 6 6];
for zz = 1:4
    [~,ii] = sort(-table_res(zz,idx_col));
    for u = 1:numel(ii)
        Rk{zz} = names_pdf(idx_col(ii));
    end
    % Now also numeric values
    Rk_num(1:ncol,zz) = idx_col(ii);
    Rk_num2(1:ncol,zz) = ii_col(ii);
end
% Sort based on likelihood
L_rank = cell(1,1); zz = 9;
[~,ii] = sort(-table_res(zz,:));
for u = 1:numel(ii)
    L_rank{1} = names_pdf(ii);
end


%% Print correlation of loglikelihood and other metrics
% % idx = [1:8 10 11 12]; %isnan(table_res), isinf(table_res); %[ 15 20], [12 17]
% % R = nan(1,numel(idx));
% % for i = 1:numel(idx)
% %     r = corrcoef(table_res(idx(i),idx_col),table_res(9,idx_col));
% %     R(1,i) = r(1,2);
% % end
idx = (table_res(9,:)~=-inf);
R = corr(table_res(:,idx)'); R = [R(9,1:8) R(9,10:12)];
% Print to screen
str = cell(1,11);
for z = 1:11
    if R(1,z) > 0
        str{z} = strcat('\multicolumn{1}{c}{$',num2str(R(1,z),'%5.3f'),'$}');
    else
        str{z} = strcat('\multicolumn{1}{c}{-$',num2str(abs(R(1,z)),'%5.3f'),'$}');
    end
end
str_tab = strcat('%s');
for ii = 1:11
    str_tab = strcat(str_tab,' & %s');
end
str_tab = strcat(str_tab,'\\\\');
fprintf(str_tab,str{1:end});
fprintf('\n');

%% Now get the PDF at desired times 
T = [1660 1700 1720 1740 1780 1800 1820 1840];
for u = 1:numel(idx_col)
    idx = idx_col(u);
    % Get optimal parameter values
    a = beta{idx}; ii = find(a(:,end)==max(a(:,end)));
    x = a(ii(1),1:end-1);
    % Now get right settings for options
    options.PDF = char(V_and_PDF(idx,2)); options.VAR = char(V_and_PDF(idx,1));
    % Now call function using evaluation period
    [X,pdfT{idx},cdfT{idx},predT{idx}] = BMA_mixture(x,D_eval,T,options);
end
cl = {'r','b'}; idx_plot = [23 27]; % 23 and 27
for u = 1:numel(idx_plot)
    for t = 1:numel(T)
        subplot(2,4,t),plot(X,pdfT{idx_plot(u)}(t,:),char(cl(u))); hold on
    end
end